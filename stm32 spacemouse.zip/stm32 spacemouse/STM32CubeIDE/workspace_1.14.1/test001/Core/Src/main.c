/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usb_device.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdbool.h>
//#include "usbd_hid.h"
//#include "usbd_custom_hid_if.h"
//#include "usbd_customhid.h"
#include "ssd1306.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
struct smData_t{
	uint8_t reportId;
	uint8_t xl;
	uint8_t xh;
	uint8_t yl;
	uint8_t yh;
	uint8_t zl;
	uint8_t zh;
};

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define DEADZONE 1
#define ADCDIV 16
//#define ADCRES 12
#define ADCMAX (2032/ADCDIV) //+-127
#define ADCMIN 0

#define PTHRESH 8
#define PTHRESHR 3
#define THRESH 40
#define THRESHR 30
#define ZTHRESH 40
#define ZTHRESHR 30
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;

I2C_HandleTypeDef hi2c1;

/* USER CODE BEGIN PV */

//extern USBD_HandleTypeDef hUsbDeviceFS;

uint16_t x1origin;
uint16_t y1origin;
uint16_t x2origin;
uint16_t y2origin;
uint16_t x3origin;
uint16_t y3origin;

static bool j1HoldP;
static bool j2HoldP;
static bool j3HoldP;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_ADC1_Init(void);
static void MX_I2C1_Init(void);
/* USER CODE BEGIN PFP */
void send_command(int16_t x, int16_t y, int16_t z, int16_t rx, int16_t ry, int16_t rz);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  char mytext[]= "Joy6Dof";
  //uint8_t adNum = 0;
  uint16_t readValue[6];
  uint16_t mv[6] = {0};
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC1_Init();
  MX_I2C1_Init();
  MX_USB_DEVICE_Init();
  /* USER CODE BEGIN 2 */
  ssd1306_Init();
  //ssd1306_Fill(White);
  //ssd1306_UpdateScreen();

  ssd1306_SetCursor(15, 5);
  //ssd1306_WriteString( mytext, Font_6x8, White);
  ssd1306_WriteString( mytext, Font_16x26, White);
  ssd1306_UpdateScreen();

  HAL_ADC_Start(&hadc1);
  HAL_ADC_Start_DMA(&hadc1, readValue, 6);
  HAL_Delay(1000);

  x1origin = readValue[3];
  y1origin = readValue[2];
  x2origin = readValue[0];
  y2origin = readValue[1];
  x3origin = readValue[4];
  y3origin = readValue[5];
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  //readValue[0];
#if 0
	   uint8_t cnt;
	   cnt++;
	   ssd1306_SetCursor(55, 5);
	   ssd1306_WriteChar( cnt, Font_6x8, White);
	   ssd1306_UpdateScreen();
#endif
	   /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
#if 1
	   int x1pos = (readValue[3]-x1origin)/ADCDIV; //rot //?���?????
	   int y1pos = (readValue[2]-y1origin)/ADCDIV; //rot //上正
	   int x2pos = (readValue[0]-x2origin)/ADCDIV; //pan //?���?????
	   int y2pos = (readValue[1]-y2origin)/ADCDIV; //pan //下正
	   int x3pos = (readValue[4]-x3origin)/ADCDIV; //pan //?���?????
	   int y3pos = (readValue[5]-y3origin)/ADCDIV; //pan //下正

	   if(abs(x1pos)< DEADZONE){x1pos=0;}
	   if(abs(y1pos)< DEADZONE){y1pos=0;}
	   if(abs(x2pos)< DEADZONE){x2pos=0;}
	   if(abs(y2pos)< DEADZONE){y2pos=0;}
	   if(abs(x3pos)< DEADZONE){x3pos=0;}
	   if(abs(y3pos)< DEADZONE){y3pos=0;}

	   uint16_t x1poss = abs(x1pos)*abs(x1pos);
	   uint16_t y1poss = abs(y1pos)*abs(y1pos);
	   uint16_t x2poss = abs(x2pos)*abs(x2pos);
	   uint16_t y2poss = abs(y2pos)*abs(y2pos);
	   uint16_t x3poss = abs(x3pos)*abs(x3pos);
	   uint16_t y3poss = abs(y3pos)*abs(y3pos);

	   if(x1poss+y1poss >= PTHRESH*PTHRESH){
	     j1HoldP = true;
	   }else if(x1poss+y1poss < PTHRESHR*PTHRESHR){
	     j1HoldP = false;
	   }
	   if(x2poss+y2poss >= PTHRESH*PTHRESH){
	     j2HoldP = true;
	   }else if(x2poss+y2poss < PTHRESHR*PTHRESHR){
	     j2HoldP = false;
	   }
	   if(x3poss+y3poss >= PTHRESH*PTHRESH){
	     j3HoldP = true;
	   }else if(x3poss+y3poss < PTHRESHR*PTHRESHR){
	     j3HoldP = false;
	   }
#endif

#if 1
	   if(j1HoldP && j3HoldP){
	       mv[0] = -y3pos;  // x
	       mv[1] = -x3pos;  // zoom
	       mv[2] = 0;      // y

	       mv[3] = 0;  // rz
	       mv[4] = 0;  // ry
	       mv[5] = 0;  // rx

	   }else{
#if 0
	       if(abs(y3pos)>=abs(x3pos)){
	         x3pos = 0;
	       }else{
	         y3pos = 0;
	       }
#endif
#if 1
	       if(abs(x2pos)>=abs(y2pos)){
	         y2pos = 0;
	       //}else{
	       	         //y3pos = 0;
	       }
#endif
	       mv[0] = 0;  // x
	       mv[1] = 0;  // y zoom
	       //mv[2] = -y2pos;  // z
	       mv[2] = -(y2pos * 2);  // z

	       mv[3] = x1pos;  // rz
	       mv[4] = y1pos;  // ry
	       mv[5] = -x2pos;  // rx
	   }

	   send_command(mv[0], mv[1], mv[2], mv[3], mv[4], mv[5]);
#endif
	   //send_command(5, 5, 5, 5, 5, 5);
	   //send_command(0, 0, -y2pos, 0, 0, -x2pos);
	  //send_command(0, 0, 0, 0, x3pos, 0);
	  //send_command(0, 0, 5, 0, 0, 5);
	  //send_command(5, 5, 5, 5, 5, 5);
	  HAL_Delay(10);
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC|RCC_PERIPHCLK_USB;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV6;
  PeriphClkInit.UsbClockSelection = RCC_USBCLKSOURCE_PLL_DIV1_5;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Common config
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ScanConvMode = ADC_SCAN_ENABLE;
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 6;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_1CYCLE_5;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = ADC_REGULAR_RANK_2;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_2;
  sConfig.Rank = ADC_REGULAR_RANK_3;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_3;
  sConfig.Rank = ADC_REGULAR_RANK_4;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_4;
  sConfig.Rank = ADC_REGULAR_RANK_5;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_5;
  sConfig.Rank = ADC_REGULAR_RANK_6;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 400000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
#if 0
void send_command(int16_t x, int16_t y, int16_t z, int16_t rx, int16_t ry, int16_t rz){

  //while(!usb_hid.ready());
  uint8_t trans[6] = { x & 0xFF, x >> 8, y & 0xFF, y >> 8, z & 0xFF, z >> 8 };
  //usb_hid.sendReport(1,trans, sizeof(trans));
  USBD_HID_SendReport(&hUsbDeviceFS,&trans,sizeof(trans));

  while(!usb_hid.ready());
  uint8_t rot[6] = { rx & 0xFF, rx >> 8, ry & 0xFF, ry >> 8, rz & 0xFF, rz >> 8 };
  //usb_hid.sendReport(2,rot, sizeof(rot));
  USBD_HID_SendReport(&hUsbDeviceFS,&rot,sizeof(rot));
}
#else
void send_command(int16_t x, int16_t y, int16_t z, int16_t rx, int16_t ry, int16_t rz){

	  struct smData_t tra;
	  struct smData_t rot;

	  tra.reportId = 1;
	  tra.xl = x & 0xFF;
	  tra.xh = x >> 8;
	  tra.yl = y & 0xFF;
	  tra.yh = y >> 8;
	  tra.zl = z & 0xFF;
	  tra.zh = z >> 8;

	  USBD_CUSTOM_HID_SendReport_FS(&tra,7);

	  rot.reportId = 2;
	  rot.xl = rx & 0xFF;
	  rot.xh = rx >> 8;
	  rot.yl = ry & 0xFF;
	  rot.yh = ry >> 8;
	  rot.zl = rz & 0xFF;
	  rot.zh = rz >> 8;

	  USBD_CUSTOM_HID_SendReport_FS(&rot,7);

	}
#endif
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
